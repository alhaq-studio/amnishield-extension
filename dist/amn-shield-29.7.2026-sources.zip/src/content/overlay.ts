import type { BlockDecision } from "../lib/types";

const STYLE = `
:host { all: initial; }
.amnshield-root {
  position: fixed;
  inset: 0;
  z-index: 2147483647;
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: "Inter", system-ui, -apple-system, "Segoe UI", sans-serif;
  background: var(--bg, #eedbd0);
  color: var(--ink, #2d1b14);
  opacity: 0;
  transition: opacity 0.6s cubic-bezier(0.22, 0.61, 0.36, 1);
}
.amnshield-root.visible { opacity: 1; }

.amnshield-root.theme-sunset {
  --bg: #eedbd0;
  --surface: #ffffff;
  --surface-2: #e6c2af;
  --ink: #2d1b14;
  --accent: #a45833;
  --muted: #755b53;
  --faint: #b9a298;
  --line: #d7bcae;
  --ring: rgba(164, 88, 51, 0.09);
  --state: rgba(164, 88, 51, 0.05);
}

.amnshield-root.theme-emerald {
  --bg: #f3f1ec;
  --surface: #ffffff;
  --surface-2: #d9e8e0;
  --ink: #202724;
  --accent: #3c7a67;
  --muted: #536159;
  --faint: #c1c7c2;
  --line: #dbddd8;
  --ring: rgba(60, 122, 103, 0.09);
  --state: rgba(60, 122, 103, 0.05);
}

.amnshield-root.theme-cosmic {
  --bg: #140d26;
  --surface: #241840;
  --surface-2: #34255c;
  --ink: #f3ecff;
  --accent: #c8b8ff;
  --muted: #988baf;
  --faint: #4e3f66;
  --line: #34255c;
  --ring: rgba(200, 184, 255, 0.15);
  --state: rgba(200, 184, 255, 0.08);
}

.amnshield-root.theme-dark {
  --bg: #0b0b0c;
  --surface: #161617;
  --surface-2: #1f1f21;
  --ink: #edece9;
  --accent: #26a69a;
  --muted: #8f8b84;
  --faint: #65615b;
  --line: #2a2a2c;
  --ring: rgba(237, 236, 233, 0.1);
  --state: rgba(237, 236, 233, 0.06);
}
.card {
  width: min(460px, 86vw);
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  gap: 26px;
  padding: 8px;
}
.breath {
  position: relative;
  width: 92px;
  height: 92px;
  border-radius: 50%;
  border: 1.5px solid var(--ink, rgba(26, 25, 23, 0.38));
  display: flex;
  align-items: center;
  justify-content: center;
  animation: breathe 6s cubic-bezier(0.45, 0, 0.55, 1) infinite;
}
.breath::before {
  content: "";
  position: absolute;
  inset: -16px;
  border-radius: 50%;
  border: 1px solid var(--ring, rgba(26, 25, 23, 0.14));
}
.breath span {
  font-size: 12px;
  letter-spacing: 0.2em;
  text-transform: uppercase;
  color: var(--muted, rgba(26, 25, 23, 0.52));
}
.breath .cue { display: inline-grid; }
.breath .cue > span {
  grid-area: 1 / 1;
  animation: cue-in 6s cubic-bezier(0.45, 0, 0.55, 1) infinite;
}
.breath .cue .out { animation-name: cue-out; }
.breath .static { display: none; }
@keyframes breathe {
  0%, 100% { transform: scale(0.82); }
  50% { transform: scale(1.12); }
}
@keyframes cue-in {
  0%, 44% { opacity: 1; }
  50%, 94% { opacity: 0; }
  100% { opacity: 1; }
}
@keyframes cue-out {
  0%, 44% { opacity: 0; }
  50%, 94% { opacity: 1; }
  100% { opacity: 0; }
}
@media (prefers-reduced-motion: reduce) {
  .amnshield-root { transition: none; }
  .breath { animation: none; transform: none; }
  .breath .cue { display: none; }
  .breath .static { display: inline; }
}
.message {
  font-size: 21px;
  line-height: 1.5;
  margin: 0;
  max-width: 38ch;
  white-space: pre-line;
}
.body { display: flex; flex-direction: column; gap: 14px; width: 100%; align-items: center; }
.sentence { font-style: italic; font-size: 15px; opacity: 0.7; max-width: 36ch; margin: 0; }
.note { font-size: 14px; opacity: 0.6; margin: 0; }
input, textarea {
  font-family: inherit;
  font-size: 15px;
  width: 100%;
  max-width: 340px;
  background: transparent;
  border: 1px solid var(--line, rgba(26, 25, 23, 0.25));
  border-radius: 14px;
  padding: 11px 14px;
  color: inherit;
  outline: none;
}
button {
  font-family: inherit;
  font-size: 15px;
  cursor: pointer;
  border-radius: 999px;
  padding: 13px 28px;
  transition: opacity 0.3s ease;
}
.primary {
  border: 1.5px solid var(--accent, currentColor);
  background: var(--accent);
  color: var(--bg, #eedbd0);
  min-width: 220px;
  font-weight: 600;
}
.primary:disabled { opacity: 0.4; cursor: default; }
.ghost {
  border: none;
  background: none;
  color: var(--muted, rgba(26, 25, 23, 0.55));
  padding: 8px;
}
.ghost:hover { opacity: 0.7; }
`;

function makePrimary(label: string, onClick: () => void, disabled = false): HTMLButtonElement {
  const button = document.createElement("button");
  button.className = "primary";
  button.textContent = label;
  button.disabled = disabled;
  button.onclick = onClick;
  return button;
}

function makeNote(text: string): HTMLParagraphElement {
  const note = document.createElement("p");
  note.className = "note";
  note.textContent = text;
  return note;
}

export interface OverlayHandlers {
  onProceed: (minutes?: number) => void;
  onLeave: () => void;
  onEndFocus: () => void;
}

export interface Overlay {
  show: (decision: BlockDecision, handlers: OverlayHandlers) => void | Promise<void>;
  hide: () => void;
}

export function createOverlay(): Overlay {
  let host: HTMLDivElement | null = null;
  const timers = new Set<ReturnType<typeof setInterval>>();

  function mount(): ShadowRoot {
    host = document.createElement("div");
    host.id = "amnshield-overlay-host";
    const shadow = host.attachShadow({ mode: "open" });
    const style = document.createElement("style");
    style.textContent = STYLE;
    shadow.appendChild(style);
    (document.documentElement || document.body).appendChild(host);
    return shadow;
  }

  function countdown(seconds: number, onTick: (left: number) => void, onDone: () => void): void {
    let left = seconds;
    onTick(left);
    if (left <= 0) {
      onDone();
      return;
    }
    const id = setInterval(() => {
      left -= 1;
      onTick(left);
      if (left <= 0) {
        clearInterval(id);
        timers.delete(id);
        onDone();
      }
    }, 1000);
    timers.add(id);
  }

  async function show(decision: BlockDecision, handlers: OverlayHandlers) {
    if (host) hide();
    const shadow = mount();
    document.documentElement.style.overflow = "hidden";

    let activeTheme = "emerald";
    try {
      const res = await browser.storage.local.get("settings");
      const settings = res.settings as any;
      if (settings?.theme) {
        activeTheme = settings.theme;
      }
      if (activeTheme === "system") {
        const isDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
        activeTheme = isDark ? "dark" : "emerald";
      }
    } catch (e) {
      console.error("Failed to load theme settings for overlay", e);
    }

    const root = document.createElement("div");
    root.className = `amnshield-root theme-${activeTheme}`;
    root.setAttribute("role", "dialog");
    root.setAttribute("aria-modal", "true");
    root.setAttribute("aria-label", "A mindful pause from AmniShield");
    root.innerHTML = `
      <div class="card" tabindex="-1">
        <div class="breath" aria-hidden="true">
          <span class="cue"><span class="in">Breathe in</span><span class="out">Breathe out</span></span>
          <span class="static">Breathe</span>
        </div>
        <p class="message">${escapeHtml(decision.message)}</p>
        <div class="body"></div>
        <button class="ghost">Take me somewhere calmer</button>
      </div>`;
    shadow.appendChild(root);
    requestAnimationFrame(() => root.classList.add("visible"));
    root.querySelector<HTMLButtonElement>(".ghost")!.onclick = handlers.onLeave;
    root.querySelector<HTMLElement>(".card")!.focus();
    trapFocus(root, shadow, handlers.onLeave);

    const body = root.querySelector<HTMLDivElement>(".body")!;

    if (decision.source === "focus") {
      renderFocus(body, decision, handlers);
      return;
    }

    if (decision.groupId === "guardian-policy") {
      renderGuardian(body, decision, handlers);
      return;
    }

    const warning = decision.warning;
    const proceed = (minutes?: number) => {
      handlers.onProceed(minutes);
      hide();
    };

    if (warning && warning.delaySeconds > 0 && decision.canProceed) {
      const wait = document.createElement("p");
      wait.className = "note";
      body.appendChild(wait);
      countdown(
        warning.delaySeconds,
        (left) => (wait.textContent = `Hold on a moment… ${left}s`),
        () => {
          body.innerHTML = "";
          renderChallenge(body, decision, proceed);
        },
      );
    } else {
      renderChallenge(body, decision, proceed);
    }
  }

  function renderFocus(body: HTMLDivElement, decision: BlockDecision, handlers: OverlayHandlers): void {
    if (decision.focusExitable) {
      body.appendChild(
        makePrimary("End focus session", () => {
          handlers.onEndFocus();
          hide();
        }),
      );
    } else {
      body.appendChild(makeNote("I'll stay until the timer is done."));
    }
  }

  function renderGuardian(body: HTMLDivElement, decision: BlockDecision, handlers: OverlayHandlers): void {
    body.appendChild(makeNote("🛡️ Blocked by AmniShield System Policy"));
  }

  function renderChallenge(body: HTMLDivElement, decision: BlockDecision, proceed: (minutes?: number) => void): void {
    const warning = decision.warning;

    if (!decision.canProceed) {
      body.appendChild(
        makeNote(
          warning?.challenge === "never"
            ? "This one stays closed for now."
            : "You've used all your passes for now. Come back later.",
        ),
      );
      return;
    }

    if (warning?.challenge === "effort") {
      const sentence = document.createElement("p");
      sentence.className = "sentence";
      sentence.textContent = warning.sentence;
      const input = document.createElement("input");
      input.setAttribute("autocomplete", "off");
      input.placeholder = "Type it here";
      const button = makePrimary("Continue", () => !button.disabled && proceed(), true);
      const check = () => (button.disabled = input.value.trim() !== warning.sentence.trim());
      input.oninput = check;
      body.append(sentence, input, button);
      check();
      input.focus();
      return;
    }

    // Wait to unlock: grant temporary access. Fixed uses the preset minutes;
    // dynamic lets me choose how long right here, then asks again next time.
    const minutes = Math.max(1, warning?.unlockMinutes ?? 15);
    if (warning?.waitType === "dynamic") {
      const input = document.createElement("input");
      input.type = "number";
      input.min = "1";
      input.value = String(minutes);
      input.setAttribute("autocomplete", "off");
      const chosen = () => Math.max(1, Math.floor(Number(input.value)) || 0);
      const button = makePrimary(`Unlock for ${chosen()} min`, () => proceed(chosen()));
      input.oninput = () => (button.textContent = `Unlock for ${chosen()} min`);
      body.append(input, button);
      input.focus();
    } else {
      body.appendChild(makePrimary(`Unlock for ${minutes} min`, () => proceed(minutes)));
    }
  }

  function hide() {
    for (const id of timers) clearInterval(id);
    timers.clear();
    document.documentElement.style.overflow = "";
    host?.remove();
    host = null;
  }

  return { show, hide };
}

// Keep keyboard focus inside the overlay and let Escape lead somewhere calmer.
// Listeners live on `root`, which is removed wholesale in hide(), so they need
// no separate teardown.
function trapFocus(root: HTMLElement, shadow: ShadowRoot, onEscape: () => void): void {
  root.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      e.preventDefault();
      onEscape();
      return;
    }
    if (e.key !== "Tab") return;
    const items = Array.from(
      root.querySelectorAll<HTMLElement>("button, input, textarea, [href]"),
    ).filter((el) => !el.hasAttribute("disabled"));
    if (items.length === 0) {
      e.preventDefault();
      return;
    }
    const first = items[0];
    const last = items[items.length - 1];
    const active = shadow.activeElement as HTMLElement | null;
    if (e.shiftKey && (active === first || active === null)) {
      e.preventDefault();
      last.focus();
    } else if (!e.shiftKey && active === last) {
      e.preventDefault();
      first.focus();
    }
  });
}

function escapeHtml(value: string): string {
  return value.replace(/[&<>"']/g, (c) => {
    return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!;
  });
}
